﻿/*  This file is part of the "Simple IAP System" project by Rebound Games.
 *  You are only allowed to use these resources if you've bought them directly or indirectly
 *  from Rebound Games. You shall not license, sublicense, sell, resell, transfer, assign,
 *  distribute or otherwise make available to any third party the Service or the Content. 
 */

using UnityEngine;
using System.Collections;
using UnityEngine.UI;

/// <summary>
/// stretches a container rect transform to include all children.
/// Also repositions children using the GridLayoutGroup, if found.
/// </summary>
public class UIPanelStretch : MonoBehaviour
{
    public int maxCellSizeX;
    public int maxCellSizeY;

    public void Reposition()
    {
        RectTransform rectTrans = GetComponent<RectTransform>();
        GridLayoutGroup grid = GetComponent<GridLayoutGroup>();

        if (rectTrans != null && grid != null)
        {
            RectTransform child = transform.GetChild(0).GetComponent<RectTransform>();
            
            switch (grid.startAxis)
            {
                case GridLayoutGroup.Axis.Vertical:
                    grid.cellSize = new Vector2(rectTrans.rect.width, child.rect.height);
                    float newHeight = child.rect.height * transform.childCount;
                    newHeight += (transform.childCount - 1) * grid.spacing.y + grid.padding.top + grid.padding.bottom;
                    rectTrans.sizeDelta = new Vector2(rectTrans.sizeDelta.x, newHeight);
                    break;
                case GridLayoutGroup.Axis.Horizontal:
                    grid.cellSize = new Vector2(child.rect.width, rectTrans.rect.height);
                    float newWidth = child.rect.width * transform.childCount;
                    newWidth += (transform.childCount - 1) * grid.spacing.x + grid.padding.left + grid.padding.right;
                    rectTrans.sizeDelta = new Vector2(newWidth, rectTrans.sizeDelta.y);
                    break;
            }

            if(maxCellSizeX > 0 && grid.cellSize.x > maxCellSizeX)
                grid.cellSize = new Vector2(maxCellSizeX, grid.cellSize.y);
            if (maxCellSizeY > 0 && grid.cellSize.y > maxCellSizeY)
                grid.cellSize = new Vector2(grid.cellSize.x, maxCellSizeY);

            grid.enabled = true;
        }
    }
}
